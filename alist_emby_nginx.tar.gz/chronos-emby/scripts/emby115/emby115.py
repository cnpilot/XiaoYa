#!/usr/local/bin/python3
#coding:  utf-8
__author__ = 'T3rry'
import re
import sys,os,time
import json,requests
import urllib
from flask import Flask, request, jsonify,redirect
import requests
import json
from urllib.parse import urlparse, urlunparse, urljoin, quote
#外网地址
emby_www = "http://www.xxx.com:8096"
#内网地址
emby_loc = "http://172.17.0.1:8096"
#alist地址
alist_loc = "http://172.17.0.1:5244/d"
#jellyfin需要填key,emby不需要
jellyfin_api_key = ''

挂载字典={'/mnt/alist':'',}

def get_alisturl(modified_path,original_headers):

    response = requests.get(modified_path,headers=original_headers, allow_redirects=False)

    # 检查是否是302状态码
    if response.status_code == 302:
        # 获取重定向地址并打印
        redirected_url = response.headers['Location']
        return redirected_url
    return False

app = Flask(__name__)

@app.route('/<path:path>', methods=['GET', 'POST'])
def index(path=''):
    current_url = request.url 
    user_agent = request.headers.get('User-Agent')
    parsed_url = urlparse(current_url) 
    get_params = request.args
    original_headers = request.headers
    # 使用正则表达式匹配数字
    match = re.search(r'/[Vv]ideos/(\S+)/stream|[Vv]ideos/(\S+)/original|[Vv]ideos/(\S+)/master', current_url)
    MediaSourceId = request.args.get('MediaSourceId') or request.args.get('mediaSourceId')

    # 提取匹配到的数字
    if match and MediaSourceId:
        video_id = match.group(1) or match.group(2) or match.group(3)

        api_key = request.args.get('api_key') or jellyfin_api_key
        url = emby_loc+'/emby/Items/'+video_id+'/PlaybackInfo?&IsPlayback=false&api_key='+api_key
        response = requests.post(url, headers=original_headers)

        if len(video_id) > 20:
            url = emby_loc+'/Items/'+video_id+'/PlaybackInfo?UserId=00000000000000000000000000000000&IsPlayback=false&api_key='+api_key
            response = requests.get(url, headers=original_headers)

        response_data = json.loads(response.text)
        for i in response_data['MediaSources']:
            if i['Id'] == MediaSourceId:


                for key ,value  in 挂载字典.items():
                    if i['Path'].startswith(key):
                        modified_path = i['Path'][len(key.strip('/'))+1:]
                        modified_path = alist_loc+value+modified_path
                        Download_url = get_alisturl(modified_path,original_headers)
                        if Download_url:
                            return redirect(Download_url, code=301)
                        else:
                            print("Failed to retrieve File ID.")
                            return (404)
                        break
        url = urlunparse((urlparse(emby_www).scheme, urlparse(waiwang).netloc, parsed_url.path, parsed_url.params, parsed_url.query, parsed_url.fragment))
        return redirect(url+'&realplay=true', code=301)




if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)

