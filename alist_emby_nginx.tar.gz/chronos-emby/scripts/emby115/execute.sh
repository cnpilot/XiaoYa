#!/bin/bash
cd "/chronos/scripts/emby115"
source "/chronos/scripts/emby115/.venv/bin/activate"
python -u "/chronos/scripts/emby115/emby115.py"